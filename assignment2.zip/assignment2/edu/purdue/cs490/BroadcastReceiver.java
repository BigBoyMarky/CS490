package edu.purdue.cs490;

public interface BroadcastReceiver
{
	void receive(Message m);
}